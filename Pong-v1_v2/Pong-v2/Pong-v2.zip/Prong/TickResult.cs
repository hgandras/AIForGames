﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prong
{
    enum TickResult
    {
        TICK = 0,
        PLAYER_1_SCORED = 1,
        PLAYER_2_SCORED = 2
    }
}
