﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prong
{
    enum PlayerAction
    {
        DOWN = -1,
        NONE = 0,
        UP = 1
    }
}
